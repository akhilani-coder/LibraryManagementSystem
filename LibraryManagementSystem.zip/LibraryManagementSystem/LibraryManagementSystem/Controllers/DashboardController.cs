﻿using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DbContext;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Dashboard controller
    /// </summary>
    [Authorize(Roles ="Admin")]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;
        /// <summary>
        /// Initialize a new instance of <see cref="DashboardController"/>
        /// </summary>
        /// <param name="context">ApplicationDbContext object</param>
        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Shows the Genre with most available and checked out books, total number of active members
        /// </summary>
        /// <returns>View</returns>
        [HttpGet]
        public async  Task<IActionResult> Index()
        {
            var genreWithMostAvailableBooks = await _context.Books.Where(x => x.Available == 1)
                .GroupBy(x => x.Genre).OrderByDescending(x => x.Count()).Select(x => x.Key).FirstOrDefaultAsync();
            var genreWithMostCheckedOutBooks = await _context.Books.Where(x => x.Available == 0)
                .GroupBy(x => x.Genre).OrderByDescending(x => x.Count()).Select(x => x.Key).FirstOrDefaultAsync();
            var totalActiveMembers = await _context.Members.CountAsync(x => x.MembershipStatus == 1);
            var model = new DashboardViewModel()
            {
                GenreWithMostAvailableBooks = genreWithMostAvailableBooks,
                GenreWithMostCheckedOutBooks = genreWithMostCheckedOutBooks,
                TotalActiveMembers = totalActiveMembers
            };
            return View(model);
        }
    }
}
