﻿using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DbContext;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Home controller
    /// </summary>
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        /// <summary>
        /// Initialize a new instance of <see cref="HomeController"/>
        /// </summary>
        /// <param name="logger">ILogger object</param>
        /// <param name="context">ApplicationDbContext object</param>
        public HomeController(ILogger<HomeController> logger,ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }
        /// <summary>
        /// Home view
        /// </summary>
        /// <returns>View</returns>
        public async Task<IActionResult> Index()
        {
            //Retrieve the data of authenticated user
            var userEmail = User.Identity.Name;
            var user = await _context.Members.Where(x => x.UserName==userEmail).FirstOrDefaultAsync();
            return View(user);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}