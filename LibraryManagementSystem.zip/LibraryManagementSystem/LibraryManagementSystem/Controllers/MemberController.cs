﻿using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DbContext;
using LibraryManagementSystem.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Member controller
    /// </summary>
    [Authorize]
    public class MemberController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        /// <summary>
        /// Initialize a new instance of <see cref="MemberController"/>
        /// </summary>
        /// <param name="context">ApplicationDbContext object</param>
        /// <param name="userManager">UserManager object</param>
        public MemberController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        /// <summary>
        /// Display the list of members
        /// </summary>
        /// <returns>View</returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var member = await _context.Members.ToListAsync();
            return View(member);
        }
        /// <summary>
        /// Display the Add form view for Member
        /// </summary>
        /// <returns>view</returns>
        [Authorize(Roles ="Admin")]
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        /// <summary>
        /// Add the details of the user
        /// </summary>
        /// <param name="model">MemberViewModel parameter</param>
        /// <returns>View</returns>
        [HttpPost]
        public async Task<IActionResult> Add(MemberViewModel model)
        {
            if (ModelState.IsValid)
            {
                var member = new Member
                {
                    Name = model.Name,
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    Address = model.Address,
                    MembershipStatus = model.MembershipStatus
                };
                var result = await _userManager.CreateAsync(member, model.Password);
                if (result.Succeeded)
                {
                    //if user creation is Succeeded , assign role to the user
                    await _userManager.AddToRoleAsync(member, "Member");
                    return RedirectToAction("Index","Member");
                }
            }
            return View(model);
        }
    }
}
