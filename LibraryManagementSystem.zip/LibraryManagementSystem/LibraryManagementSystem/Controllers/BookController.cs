﻿using LibraryManagementSystem.Models;
using LibraryManagementSystem.Models.DbContext;
using LibraryManagementSystem.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Book controller
    /// </summary>
    [Authorize]
    public class BookController : Controller
    {
        private readonly ApplicationDbContext _context;
        /// <summary>
        /// Initialize a new instance of <see cref="BookController"/>
        /// </summary>
        /// <param name="context">ApplicationDbContext object</param>
        public BookController(ApplicationDbContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Display the list of book
        /// </summary>
        /// <returns>book</returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var book = await _context.Books.ToListAsync();
            return View(book);
        }
        /// <summary>
        /// Display the Add form view for book
        /// </summary>
        /// <returns>View</returns>
        [Authorize(Roles ="Admin")]
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        /// <summary>
        /// Add the details of the book
        /// </summary>
        /// <param name="model">BookViewModel parameter</param>
        /// <returns>View</returns>
        [HttpPost]
        public async Task<IActionResult> Add(BookViewModel model)
        {
            if (ModelState.IsValid)
            {
                //Convert the IFormfile to an array of byte
                byte[] ImageData = null;
                if(model.Image != null)
                {
                    using (var ms = new MemoryStream())
                    {
                        await model.Image.CopyToAsync(ms);
                        ImageData = ms.ToArray();
                    }
                }
                var book = new Book
                {
                    BookId = Guid.NewGuid(),
                    Title = model.Title,
                    Author = model.Author,
                    Genre = model.Genre,
                    Available = model.Available,
                    Image = ImageData
                };
                await _context.Books.AddAsync(book);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(model);
        }
    }
}
