﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class MemberViewModel
    {
        /// <summary>
        /// Get or set Name
        /// </summary>
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// Get or set Email
        /// </summary>
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        /// <summary>
        /// Get or set Password
        /// </summary>
        [Required]
        public string Password { get; set; }

        /// <summary>
        /// Get or set PhoneNumber
        /// </summary>
        [Required]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Get or set Address
        /// </summary>
        [Required]
        public string Address { get; set; }

        /// <summary>
        /// Get or set MembershipStatus
        /// </summary>
        [Required]
        public int MembershipStatus { get; set; }
    }
}
