﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class BookViewModel
    {
        /// <summary>
        /// Get or set Title
        /// </summary>
        [Required]
        public string Title { get; set; }

        /// <summary>
        /// Get or set Author
        /// </summary>
        [Required]
        public string Author { get; set; }

        /// <summary>
        /// Get or set Genre
        /// </summary>
        [Required]
        public string Genre { get; set; }

        /// <summary>
        /// Get or set Available
        /// </summary>
        [Required]
        public int Available { get; set; }
        /// <summary>
        /// Get or set Image
        /// </summary>
        public IFormFile Image { get; set; }
    }
}
