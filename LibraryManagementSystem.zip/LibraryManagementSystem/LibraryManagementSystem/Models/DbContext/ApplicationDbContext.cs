﻿using LibraryManagementSystem.Models.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Models.DbContext
{
    /// <summary>
    /// Application Database context
    /// </summary>
    public class ApplicationDbContext:IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            this.SeedData(builder);
        }

        /// <summary>
        /// Seed Initial Data to the database
        /// </summary>
        /// <param name="builder"></param>
        private void SeedData(ModelBuilder builder)
        {
            //Seed role in the IdentityRole table
            List<IdentityRole> Role = new List<IdentityRole>()
            {
                new IdentityRole{Name="Admin",NormalizedName="ADMIN"},
                new IdentityRole{Name= "Member",NormalizedName="MEMBER"}
            };
            builder.Entity<IdentityRole>().HasData(Role);

            //Seed member in the member table
            List<Member> User = new List<Member>()
            {
                new Member
                {
                    Name = "Akhil",
                    UserName ="akhil@gmail.com",
                    NormalizedUserName="AKHIL@GMAIL.COM",
                    Email = "akhil@gmail.com",
                    NormalizedEmail = "AKHIL@GMAIL.COM",
                    Address= "TVM",
                    MembershipStatus = 1
                }
            };
            // Hash the password
            PasswordHasher<Member> passwordHasher = new PasswordHasher<Member>();
            User[0].PasswordHash = passwordHasher.HashPassword(User[0], "Akhil@123");
            builder.Entity<Member>().HasData(User);

            //Seed the user and corresponding role in IdentityUserRole table
            List<IdentityUserRole<string>> UserRole = new List<IdentityUserRole<string>>()
            {
                new IdentityUserRole<string>
                {
                    UserId = User[0].Id,
                    RoleId = Role.First(x => x.Name == "Admin").Id
                }
            };
            builder.Entity<IdentityUserRole<string>>().HasData(UserRole);
        }
        /// <summary>
        /// Get or set Members
        /// </summary>
        public DbSet<Member> Members { get; set; }

        /// <summary>
        /// Get or set Books
        /// </summary>
        public DbSet<Book> Books { get; set; }
    }
}
