﻿namespace LibraryManagementSystem.Models
{
    public class DashboardViewModel
    {
        /// <summary>
        /// Get or sets Genre with most available books
        /// </summary>
        public string GenreWithMostAvailableBooks { get; set; }
        /// <summary>
        /// Get or sets Genre with most checkedOut books
        /// </summary>
        public string GenreWithMostCheckedOutBooks { get; set; }

        /// <summary>
        /// Get or sets Total active members
        /// </summary>
        public int TotalActiveMembers { get; set; }
    }
}
