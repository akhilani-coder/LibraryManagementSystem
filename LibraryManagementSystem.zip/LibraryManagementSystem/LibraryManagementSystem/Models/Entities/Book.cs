﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models.Entities
{
    public class Book
    {
        /// <summary>
        /// Get or set Guid
        /// </summary>
        public Guid BookId { get; set; }

        /// <summary>
        /// Get or set Title
        /// </summary>
        [Required]
        public string Title { get; set; }

        /// <summary>
        /// Get or set Author
        /// </summary>
        [Required]
        public string Author { get; set; }

        /// <summary>
        /// Get or set Genre
        /// </summary>
        [Required]
        public string Genre { get; set; }
        /// <summary>
        /// Get or set Available
        /// </summary>
        [Required]
        public int Available { get; set; }
        /// <summary>
        /// Get or set Image as byte array
        /// </summary>
        public byte[] Image { get; set; }

        /// <summary>
        /// Get or set Image(not mapped in database)
        /// </summary>
        [NotMapped]
        public IFormFile ImageFile { get; set; }
    }
}
