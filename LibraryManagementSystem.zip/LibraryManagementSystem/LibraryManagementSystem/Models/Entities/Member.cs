﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models.Entities
{
    public class Member : IdentityUser
    {
        /// <summary>
        /// Get or sets Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Get or set Address
        /// </summary>
        [Required]
        public string Address { get; set; }

        /// <summary>
        /// Get or set MembershipStatus
        /// </summary>
        [Required]
        public int MembershipStatus { get; set; }
    }
}
