﻿namespace LibraryManagementSystem.Models
{
    public class LoginViewModel
    {
        /// <summary>
        /// Get or set Email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Get or set Password
        /// </summary>
        public string Password { get; set; }
    }
}
